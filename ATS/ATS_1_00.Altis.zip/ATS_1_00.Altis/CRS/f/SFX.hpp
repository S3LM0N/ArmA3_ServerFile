#define CRS_sfx
#define CRS titles[]={""};
class dry {name="dry";sound[]={"@A3\Sounds_F\weapons\Other\sfx1.wss",db-3,1};CRS};