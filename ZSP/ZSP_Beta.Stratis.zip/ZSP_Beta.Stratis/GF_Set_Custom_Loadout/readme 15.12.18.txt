


//________________  Author : GEORGE FLOROS [GR] ___________ 15.12.18 _____________

/*
________________ GF Set Custom Loadout Script ________________

https://forums.bohemia.net/forums/topic/219669-gf-set-custom-loadout-script/

Please keep the Credits or add them to your Diary

https://community.bistudio.com/wiki/SQF_syntax
Don't try to open this with the simple notepad.
For everything that is with comment  //  in front  or between /*
means that it is disabled , so there is no need to delete the extra lines.

You can open this ex:
with notepad++
https://notepad-plus-plus.org/

and also use the extra pluggins
(this way will be better , it will give also some certain colours to be able to detect ex. problems )
http://www.armaholic.com/page.php?id=8680

or use any other program for editing .

For the Compilation List of my GF Scripts , you can search in:
https://forums.bohemia.net/forums/topic/215850-compilation-list-of-my-gf-scripts/
*/


Changelog:

Version 3.0

Script Author :
 
by GEORGE FLOROS [GR]


Description:

GF Set Custom Loadout Script , Set your Custom Loadout to AI and Players.
You are free to do anything but i would like to give me Credits for this!
Simple and easy to use and adapt .
Have Fun !


Installation / Usage:

For usage instructions and information of how to use the GF Set Custom Loadout Script please refer to the included documentation and/or example mission.
Place in your mission the files . There is everything included , in the initServer.sqf  , to copy paste in your mission .

https://community.bistudio.com/wiki/SQF_syntax
Don't try to open this with the simple notepad.
For everything that is with comment  //  in front  or between /* 
means that it is disabled , so there is no need to delete the extra lines. 

You can open this ex:
with notepad++
https://notepad-plus-plus.org/

and also use the extra pluggins
(this way will be better , it will give also some certain colours to be able to detect ex. problems )
http://www.armaholic.com/page.php?id=8680

or use any other program for editing . 

For the Compilation List of my GF Scripts , you can search in:
https://forums.bohemia.net/forums/topic/215850-compilation-list-of-my-gf-scripts/


Notes:

It is also included a mod version , posible to unpack and edit. 
It is possible to set the loadout also for the spawned units.
There is an exclude list available or add in the init of a unit:
this setVariable ["Var_GF_Set_Custom_Loadout", true];
More information inside the .sqf
Added files for :
CUP mod , RHS mod , Unsung mod ,
with different variables for everyone.
It is also possible to ran multiple .sqf , 
just filter the side ex: east (see inside .sqf) or variables ex: spawn GF_Set_Custom_Loadout_1;


Credits and Thanks to :

Thanks to All script contributors
Thanks to everyone who tries to do the best for this game!
Thanks to BIS for such a great platform .
Thanks to BIS Community and BIS Community Forums .
Thanks to Armaholic Community and Forums .


Changelog:

v3.0 
Added extended options , in order to spawn a different loadout for each side.
Several Fixes.

v2.0 
Added files for :
CUP mod , RHS mod , Unsung mod ,
with different variables for everyone.
Full ACE3 mod list 
Added options for Ravage mod and ACE3 mod.
Several fixes.

v1.0 

  
Requirements : 

No addons required 


more info in :

Forum topic:
- BI forums https://forums.bohemia.net/forums/topic/219669-gf-set-custom-loadout-script/
- Armaholic forums http://www.armaholic.com/forums.php?m=posts&q=40244


Disclaimer :

I take no responsibility for (im)possible damage to your game/system that may be caused by installation of this Mission.

ALL CONTENT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. I MAKE NO WARRANTIES, EXPRESS OR IMPLIED, 
THAT THEY ARE FREE OF ERROR, OR ARE CONSISTENT WITH ANY PARTICULAR STANDARD OF MERCHANTABILITY, OR THAT 
THEY WILL MEET YOUR REQUIREMENTS FOR ANY PARTICULAR APPLICATION. USE AT YOUR OWN RISK. THE AUTHOR AND 
PUBLISHER DISCLAIM ALL LIABILITY FOR DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES RESULTING FROM YOUR 
USE OF THE PROGRAMS.  