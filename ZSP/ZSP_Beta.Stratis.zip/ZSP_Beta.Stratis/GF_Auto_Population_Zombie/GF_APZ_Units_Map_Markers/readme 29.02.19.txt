


//___________________  Author : GEORGE FLOROS [GR] ___________	29.01.19	_____________

/*
___________________	GF Units Map Markers and Symbols Script - Mod	___________________

https://forums.bohemia.net/forums/topic/219763-gf-units-map-markers-and-symbols-script/

Please keep the Credits or add them to your Diary

https://community.bistudio.com/wiki/SQF_syntax
Don't try to open this with the simple notepad.
For everything that is with comment  //  in front  or between /*
means that it is disabled , so there is no need to delete the extra lines.

You can open this ex:
with notepad++
https://notepad-plus-plus.org/

ArmA 3 | Notepad ++ SQF tutorial
https://www.youtube.com/watch?v=aI5P7gp3x90

and also use the extra pluggins
(this way will be better , it will give also some certain colours to be able to detect ex. problems )
http://www.armaholic.com/page.php?id=8680

or use any other program for editing .

For the Compilation List of my GF Scripts , you can search in:
https://forums.bohemia.net/forums/topic/215850-compilation-list-of-my-gf-scripts/
*/


Changelog:

Version 3.0

Script Author :
 
by GEORGE FLOROS [GR]


Description:

GF Units Map Markers and Symbols Script , simple Map Markers for AI and Players.
You are free to do anything but i would like to give me Credits for this!
Simple and easy to use and adapt .
Have Fun !


Installation / Usage:

For usage instructions and information of how to use the GF Units Map Markers and Symbols Script please refer to the included documentation and/or example mission.
Place in your mission the files . There is everything included , in the initServer.sqf  , to copy paste in your mission .

https://community.bistudio.com/wiki/SQF_syntax
Don't try to open this with the simple notepad.
For everything that is with comment  //  in front  or between /* 
means that it is disabled , so there is no need to delete the extra lines. 

You can open this ex:
with notepad++
https://notepad-plus-plus.org/

ArmA 3 | Notepad ++ SQF tutorial
https://www.youtube.com/watch?v=aI5P7gp3x90

and also use the extra pluggins
(this way will be better , it will give also some certain colours to be able to detect ex. problems )
http://www.armaholic.com/page.php?id=8680

or use any other program for editing . 

For the Compilation List of my GF Scripts , you can search in:
https://forums.bohemia.net/forums/topic/215850-compilation-list-of-my-gf-scripts/


Notes:

Simple Map Markers and Symbols for AI and Players for SP - MP and debug purpose.
It is also included a mod version , posible to unpack and edit. 
The mod has enabled only the playerSide markers.
It is possible to filter the display .
You can add in the init of a unit to exclude :
this setVariable ["Var_GF_Units_Map_Markers", true];
this setVariable ["Var_GF_Units_Map_Symbols", true];
More information inside the .sqf
Added support for :
ACE3 mod , FAR , BTC an AIS revive.


Credits and Thanks to :

Thanks to All script contributors
Thanks to everyone who tries to do the best for this game!
Thanks to BIS for such a great platform .
Thanks to BIS Community and BIS Community Forums .
Thanks to Armaholic Community and Forums .


Changelog:

v3.0
Fixed the group icon error, for the size of the unit

v2.0
Several Fixes , including type of markers , symbols and errors.
Added markers depending on side.

v1.0 

  
Requirements : 

No addons required 


more info in :

Forum topic:
- BI forums https://forums.bohemia.net/forums/topic/219763-gf-units-map-markers-and-symbols-script/
- Armaholic forums http://www.armaholic.com/forums.php?m=posts&q=40252


Disclaimer :

I take no responsibility for (im)possible damage to your game/system that may be caused by installation of this Mission.

ALL CONTENT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. I MAKE NO WARRANTIES, EXPRESS OR IMPLIED, 
THAT THEY ARE FREE OF ERROR, OR ARE CONSISTENT WITH ANY PARTICULAR STANDARD OF MERCHANTABILITY, OR THAT 
THEY WILL MEET YOUR REQUIREMENTS FOR ANY PARTICULAR APPLICATION. USE AT YOUR OWN RISK. THE AUTHOR AND 
PUBLISHER DISCLAIM ALL LIABILITY FOR DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES RESULTING FROM YOUR 
USE OF THE PROGRAMS.  