


//________________	Author : GEORGE FLOROS [GR]	___________	06.04.19	___________


/*
________________	GF Auto Loot Script - Mod	________________

https://forums.bohemia.net/forums/topic/220701-gf-auto-loot-script-mod/

Please keep the Credits or add them to your Diary

https://community.bistudio.com/wiki/SQF_syntax
Don't try to open this with the simple notepad.
For everything that is with comment  //  in front  or between /*
means that it is disabled , so there is no need to delete the extra lines.

You can open this ex:
with notepad++
https://notepad-plus-plus.org/

ArmA 3 | Notepad ++ SQF tutorial
https://www.youtube.com/watch?v=aI5P7gp3x90

and also use the extra pluggins
(this way will be better , it will give also some certain colors to be able to detect ex. problems )
http://www.armaholic.com/page.php?id=8680

or use any other program for editing .

For the Compilation List of my GF Scripts , you can search in:
https://forums.bohemia.net/forums/topic/215850-compilation-list-of-my-gf-scripts/

BI Forum Ravage Club Owner :
https://forums.bohemia.net/clubs/73-bi-forum-ravage-club/
*/


Changelog:

Version 3.1

Script Author :
 
by GEORGE FLOROS [GR]


Description:

GF Auto Loot Script - Mod , will detect the enable Mods , without editing lists.
You are free to do anything but i would like to give me Credits for this!
Simple and easy to use and adapt .
Have Fun !


Installation / Usage:

For usage instructions and information of how to use the GF Auto Loot Script - Mod please refer to the included documentation and/or example mission.
Place in your mission the files . There is everything included , in the initServer.sqf , to copy paste in your mission .

https://community.bistudio.com/wiki/SQF_syntax
Don't try to open this with the simple notepad.
For everything that is with comment  //  in front  or between /* 
means that it is disabled , so there is no need to delete the extra lines. 

You can open this ex:
with notepad++
https://notepad-plus-plus.org/

and also use the extra pluggins
(this way will be better , it will give also some certain colors to be able to detect ex. problems )
http://www.armaholic.com/page.php?id=8680

or use any other program for editing . 

For the Compilation List of my GF Scripts , you can search in:
https://forums.bohemia.net/forums/topic/215850-compilation-list-of-my-gf-scripts/


Notes:

GF Auto Loot Script - Mod , will detect the enable Mods , without editing lists.
There are 4 options available :
1 = Load every Mod + Bohemia Items , 2 = Load every Mod - No Bohemia Items , 3 = Load Bohemia Items Only , 4 = Custom items only

There is a Possibility option available.
There are Blacklist Zones available , 5 from default and
a safe distanse from players , to prevent the loot from spawn. 
The loot will spawn also , at the spawned or placed in editor Buildings.
There is also included a mod version , posible to unpack and edit.


Credits and Thanks to :

Thanks to All script contributors
Thanks to everyone who tries to do the best for this game!
Thanks to BIS for such a great platform .
Thanks to BIS Community and BIS Community Forums .
Thanks to Armaholic Community and Forums .


Changelog:

v3.1
Fixed , working now also on Dedicated , with auto init.

v3.0
A lot of the previous code is reedited.
Added option for the spawned items number.
Code optimization.

v2.0
It is possible to add your custom item list.
There are 4 options available :
1 = Load every Mod + Bohemia Items , 2 = Load every Mod - No Bohemia Items , 3 = Load Bohemia Items Only , 4 = Custom items only
Changed the codes for the search of the configs.
Minor Fixes.

v1.1
Minor Fix.
	
v1.0 

  
Requirements : 

No addons required 


more info in :

Forum topic:
- BI forums https://forums.bohemia.net/forums/topic/220701-gf-auto-loot-script/
- Armaholic forums http://www.armaholic.com/forums.php?m=posts&q=40299


Disclaimer :

I take no responsibility for (im)possible damage to your game/system that may be caused by installation of this Mission.

ALL CONTENT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. I MAKE NO WARRANTIES, EXPRESS OR IMPLIED, 
THAT THEY ARE FREE OF ERROR, OR ARE CONSISTENT WITH ANY PARTICULAR STANDARD OF MERCHANTABILITY, OR THAT 
THEY WILL MEET YOUR REQUIREMENTS FOR ANY PARTICULAR APPLICATION. USE AT YOUR OWN RISK. THE AUTHOR AND 
PUBLISHER DISCLAIM ALL LIABILITY FOR DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES RESULTING FROM YOUR 
USE OF THE PROGRAMS.  